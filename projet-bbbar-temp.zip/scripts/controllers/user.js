'use strict';

/**
 * @ngdoc function
 * @name myApp.controller:UserCtrl
 * @description
 * # UserCtrl
 * Controller of the myApp
 */
angular.module('myApp')
  .controller('UserCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
