'use strict';

/**
 * @ngdoc function
 * @name myApp.controller:MyrouteCtrl
 * @description
 * # MyrouteCtrl
 * Controller of the myApp
 */
angular.module('myApp')
  .controller('MyrouteCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
