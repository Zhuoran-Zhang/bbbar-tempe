'use strict';

/**
 * @ngdoc service
 * @name myApp.myService
 * @description
 * # myService
 * Service in the myApp.
 */
angular.module('myApp')
  .service('myService', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
